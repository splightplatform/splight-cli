from typing import Callable, Dict, Iterator, Optional, Tuple

import grpc

from splight_runner.grpc.logs_pb2 import LogEvent
from splight_runner.grpc.logs_pb2_grpc import LogsServiceStub


class LogsGRPCError(Exception):
    pass


class MissingGRPCService(Exception):
    pass


class LogsGRPCClient:
    AUTHORIZATION: str = "authorization"

    def __init__(self, grpc_host: str, secure_channel: bool = True):
        if secure_channel:
            self._channel = grpc.secure_channel(
                grpc_host, grpc.ssl_channel_credentials()
            )
        else:
            self._channel = grpc.insecure_channel(grpc_host)

        self._stub = LogsServiceStub(self._channel)
        self._auth_header: Optional[Tuple[str, str]] = None

    def set_authorization_header(self, access_id: str, secret_key: str):
        self._auth_header = (
            LogsGRPCClient.AUTHORIZATION,
            f"Splight {access_id} {secret_key}",
        )

    def stream_logs(self, log_generator: Callable):
        try:
            self._stub.save_log_event(
                self._parse_log_message(log_generator()),
                metadata=[self._auth_header],
            )
        except grpc.RpcError as exc:
            raise LogsGRPCError("Unable to stream component logs") from exc

    def _parse_log_message(self, message_iterator: Iterator[Dict]):
        for message in message_iterator:
            yield LogEvent(**message)
